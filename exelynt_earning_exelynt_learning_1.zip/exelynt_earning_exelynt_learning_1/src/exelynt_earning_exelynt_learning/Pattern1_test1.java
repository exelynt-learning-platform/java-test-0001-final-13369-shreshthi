package exelynt_earning_exelynt_learning;

public class Pattern1_test1 {

	public class Pattern {
		public static void main(String[] args) {

			int n = 5;

			for (int i = 1; i <= n; i++) {

				for (int s = 1; s <= n - i; s++) {
					System.out.print(" ");
				}

				System.out.print("*");

				if (i > 1) {
					for (int sp = 1; sp <= (2 * i - 3); sp++) {
						System.out.print(" ");
					}
					System.out.print("*");
				}

				System.out.println();
			}

			for (int i = n - 1; i >= 1; i--) {

				for (int s = 1; s <= n - i; s++) {
					System.out.print(" ");
				}

				System.out.print("*");

				if (i > 1) {
					for (int sp = 1; sp <= (2 * i - 3); sp++) {
						System.out.print(" ");
					}
					System.out.print("*");
				}

				System.out.println();
			}
		}
	}

}
